<?php
$hostName = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbName = "Onestop";
$conn = mysqli_connect($hostName,$dbuser,$dbpassword, $dbName) or die('connection failed');
?>