<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbName = "ProductDatabase";

$conn = mysqli_connect($dbhost, $dbuser, $dbpassword, $dbName) or die('connection failed');
?>